package com.idfc.aopdemo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    public ResponseEntity<String> getUserById(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("User ID must be greater than 0");
        }
        return ResponseEntity.ok("User-" + id);
    }
}
