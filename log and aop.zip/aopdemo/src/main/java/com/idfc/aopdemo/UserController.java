package com.idfc.aopdemo;

import com.idfc.aopdemo.service.UserService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
public class UserController {

    private static final Logger LOGGER = LogManager.getLogger(UserController.class);

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getUser(@PathVariable int id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    @GetMapping
    public String logExample() {
        LOGGER.info("INFO: Log message from LogController");
        LOGGER.warn("WARNING: Log message");
        LOGGER.error("ERROR: Log message");
        return "Log messages generated";
    }

}
