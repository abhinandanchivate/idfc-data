//package com.idfc.aopdemo;
//
//import org.aspectj.lang.annotation.*;
//import org.aspectj.lang.ProceedingJoinPoint;
//import org.aspectj.lang.annotation.Around;
//import org.aspectj.lang.annotation.Aspect;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Component;
//
//@Aspect
//@Component
//public class ExceptionHandlingAspect {
//
//    @Around("execution(* com.idfc.aopdemo.service.*.*(..))")
//    public Object handleServiceExceptions(ProceedingJoinPoint joinPoint) {
//        try {
//            return joinPoint.proceed();  // Proceed with method execution
//        } catch (IllegalArgumentException ex) {
//            return ResponseEntity.badRequest().body("Error: " + ex.getMessage());
//        } catch (Throwable ex) {
//            return ResponseEntity.internalServerError().body("An unexpected error occurred");
//        }
//    }
//}
