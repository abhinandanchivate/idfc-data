public class ThreadDemo {


    public static void main(String[] args) {
        Thread t1 = new Thread(()->{
            System.out.println("Hello from thread");
            for (int i = 0; i < 10; i++) {
                try {
                    Thread.sleep(1000);
                    System.out.println("Hello from thread"+i);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {

                System.out.println("Hello from thread 2");

            }
        });

        t1.start();
        t2.start();

    }
}
